package com.example.quiz2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btn1,btn2,btn3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.tutor1);
        btn2 = findViewById(R.id.tutor2);
        btn3 = findViewById(R.id.tutor3);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tutor1 = new Intent(MainActivity.this, com.example.quiz2.tutor1.class);
                tutor1.putExtra("url",config.YOUTUBE_VIDEO_CODE1);
                startActivity(tutor1);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tutor2 = new Intent(MainActivity.this, com.example.quiz2.tutor1.class);
                tutor2.putExtra("url",config.YOUTUBE_VIDEO_CODE2);
                startActivity(tutor2);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tutor3 = new Intent(MainActivity.this, com.example.quiz2.tutor1.class);
                tutor3.putExtra("url",config.YOUTUBE_VIDEO_CODE3);
                startActivity(tutor3);
            }
        });
    }
}
