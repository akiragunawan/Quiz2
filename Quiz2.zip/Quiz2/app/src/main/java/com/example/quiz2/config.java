package com.example.quiz2;

public class config {

    public static final String DEVELOPER_KEY = "AIzaSyCyQ9YjK_i_44cb_J_n_S_DkAOahcxndp0";
    public static final String YOUTUBE_VIDEO_CODE1 ="ji5_cGet2Yo";
    public static final String YOUTUBE_VIDEO_CODE2 ="_uQrJ0TkZlc";
    public static final String YOUTUBE_VIDEO_CODE3 ="HXV3zeQKqGY";
}
